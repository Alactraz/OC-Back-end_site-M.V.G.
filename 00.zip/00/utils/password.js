const password = 'qNZys3wPISHEaHHp';

module.exports = password;